#!/bin/bash
#SBATCH -J lora
#SBATCH -p p-RTX2080
#SBATCH -N 1
#SBATCH --cpus-per-task=10
#SBATCH --gres=gpu:3


cd /home/zhangzhihan/Time-aware-LM

time=$(date "+%m%d-%H%M")

#python run.py --config config/train_year/t5_lora15.json > script/train_year_t5_lora15_${time}.log

#python run.py --config config/train_year/t5_lora16.json > script/train_year_t5_lora16_${time}.log

#python run.py --config config/train_year/t5_lora17.json > script/train_year_t5_lora17_${time}.log

#python run.py --config config/train_year/t5_lora18.json > script/train_year_t5_lora18_${time}.log

python run.py --config config/train_year/t5_lora19.json > script/train_year_t5_lora19_${time}.log

python run.py --config config/train_year/t5_lora20.json > script/train_year_t5_lora20_${time}.log

#python run.py --config config/train_future/t5_lora16.json > script/train_future_t5_lora16_mix_${time}.log

#python run.py --config config/train_future/t5_lora17.json > script/train_future_t5_lora17_mix_${time}.log

#python run.py --config config/train_future/t5_lora18.json > script/train_future_t5_lora18_mix_${time}.log

#python run.py --config config/train_future/t5_lora19.json > script/train_future_t5_lora19_mix_${time}.log

#python run.py --config config/train_future/t5_lora20.json > script/train_future_t5_lora20_mix_${time}.log