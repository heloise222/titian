#!/bin/bash
#SBATCH -J lama
#SBATCH -p p-A100
#SBATCH -N 1
#SBATCH --cpus-per-task=20
#SBATCH --gres=gpu:4


cd /home/zhangzhihan/Time-aware-LM

time=$(date "+%m%d-%H%M")

#python run_new.py --config /home/zhangzhihan/Time-aware-LM/config/evaluation/t5_eval_perp.json

#python run.py --config config/evaluation/perp/t5_eval_perp_lora20.json

#python run.py --config config/evaluation/perp/t5_eval_perp_lora19.json

#python run.py --config config/evaluation/perp/t5_eval_perp_lora18.json

#python run.py --config config/evaluation/perp/t5_eval_perp_lora17.json

#python run.py --config config/evaluation/perp/t5_eval_perp_lora16.json

#python run.py --config config/evaluation/perp/t5_eval_perp_lora15.json

python run.py --config config/evaluation/perp/t5_eval_perp_future15.json

python run.py --config config/evaluation/perp/t5_eval_perp_future16.json

python run.py --config config/evaluation/perp/t5_eval_perp_future17.json

python run.py --config config/evaluation/perp/t5_eval_perp_future18.json

python run.py --config config/evaluation/perp/t5_eval_perp_future19.json

python run.py --config config/evaluation/perp/t5_eval_perp_future20.json