#!/bin/bash
#SBATCH -J lora
#SBATCH -p p-RTX2080
#SBATCH -N 1
#SBATCH --cpus-per-task=10
#SBATCH --gres=gpu:3


cd /home/zhangzhihan/Time-aware-LM

time=$(date "+%m%d-%H%M")

#python train_future.py > script/train_new_${time}.log

python train_future_gap2.py > script/train_new_gap2_${time}.log