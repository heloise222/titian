#!/bin/bash
#SBATCH -J lama
#SBATCH -p p-A100
#SBATCH -N 1
#SBATCH --cpus-per-task=20
#SBATCH --gres=gpu:2

cd /home/zhangzhihan/Time-aware-LM

time=$(date "+%m%d-%H%M")

#python run.py --config config/evaluation/t5_eval_lama.json > script/lama_last_${time}.log

#python run.py --config config/evaluation/t5_eval_lama_orig16.json > script/lama_orig16_${time}.log

#python run.py --config config/evaluation/t5_eval_lama_orig17.json > script/lama_orig17_${time}.log

#python run.py --config config/evaluation/t5_eval_lama_orig18.json > script/lama_orig18_${time}.log

#python run.py --config config/evaluation/t5_eval_templama.json > script/templama_future16_${time}.log

#python run.py --config config/evaluation/t5_eval_lama.json > script/lama_lora20_${time}.log

#python run.py --config config/evaluation/lama/t5_eval_templama_1.json > script/templama_lora17_2017_${time}.log

#python run.py --config config/evaluation/t5_eval_templama_1.json > script/templama_lora17_2018_${time}.log

python run.py --config config/evaluation/lama/t5_eval_lama_2015.json

python run.py --config config/evaluation/lama/t5_eval_lama_2016.json

python run.py --config config/evaluation/lama/t5_eval_lama_2017.json

python run.py --config config/evaluation/lama/t5_eval_lama_2018.json

python run.py --config config/evaluation/lama/t5_eval_lama_2019.json

python run.py --config config/evaluation/lama/t5_eval_lama_2020.json

#python run.py --config config/evaluation/lama/t5_eval_f1_2016.json

#python run.py --config config/evaluation/lama/t5_eval_f1_2017.json

#python run.py --config config/evaluation/lama/t5_eval_f1_2018.json

#python run.py --config config/evaluation/lama/t5_eval_f1_2019.json

#python run.py --config config/evaluation/lama/t5_eval_f1_2020.json