#!/bin/bash
#SBATCH -J lama
#SBATCH -p p-A100
#SBATCH -N 1
#SBATCH --cpus-per-task=20
#SBATCH --gres=gpu:0

cd /home/zhangzhihan/Time-aware-LM

time=$(date "+%m%d-%H%M")

python run.py --config config/evaluation/lama/t5_eval_f1.json

#python run.py --config config/evaluation/lama/t5_eval_templama.json

#python run.py --config config/evaluation/lama/t5_eval_lama.json
