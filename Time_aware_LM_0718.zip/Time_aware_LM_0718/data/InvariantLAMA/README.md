## Download InvariantLAMA

First download `ckl_data.zip`
```
wget https://continual.blob.core.windows.net/ckl/ckl_data.zip
unzip ckl_data.zip
```

Then find `InvariantLAMA.csv` in this folder.
