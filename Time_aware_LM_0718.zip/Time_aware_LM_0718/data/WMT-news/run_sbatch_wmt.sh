#!/bin/bash
#SBATCH -J wmt_real
#SBATCH -p p-RTX2080
#SBATCH -N 1
#SBATCH -c 4

cd /home/zhangzhihan/Time-aware-LM/data/WMT-news

time=$(date "+%m%d-%H%M")

#wget --user=newscrawl --password=acrawl4me https://data.statmt.org/news-crawl/doc/en/news-docs.2016.en.filtered.gz
#wget --user=newscrawl --password=acrawl4me https://data.statmt.org/news-crawl/doc/en/news-docs.2017.en.filtered.gz
#wget --user=newscrawl --password=acrawl4me https://data.statmt.org/news-crawl/doc/en/news-docs.2018.en.filtered.gz
#wget --user=newscrawl --password=acrawl4me https://data.statmt.org/news-crawl/doc/en/news-docs.2019.en.filtered.gz
#wget --user=newscrawl --password=acrawl4me https://data.statmt.org/news-crawl/doc/en/news-docs.2020.en.filtered.gz
#wget --user=newscrawl --password=acrawl4me https://data.statmt.org/news-crawl/doc/en/news-docs.2021.en.filtered.gz

#python wmtnews-preprocess-sample-nolama-tmp1.py

python wmtnews-preprocess-sample-nolama.py