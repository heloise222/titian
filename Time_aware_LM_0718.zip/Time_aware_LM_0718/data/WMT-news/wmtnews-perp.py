# This file now calculate the absolute perplexity of a LM on 2021 WMT News
# This file will soon be updated to calculate the relative perplexity of two LMs
import gzip
import hashlib
import base64
from tqdm import tqdm
import csv
import os
import math
from math import exp
import random
from itertools import chain
import spacy
import numpy as np

from transformers import T5Tokenizer, T5ForConditionalGeneration, T5Config
import torch
from torch.utils.data import DataLoader


def wmt_preprocess(file):
    with gzip.open(file) as gz_file:
        for line in gz_file:
            date, sentence_split_text, unsplit_text = line.decode('utf-8').strip().split('\t')
            docid = hashlib.sha256(unsplit_text.encode('utf-8')).hexdigest()
            sentence_split_text = base64.b64decode(sentence_split_text)
            unsplit_text = base64.b64decode(unsplit_text)
            yield docid, (date, sentence_split_text, unsplit_text)


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
spacy.prefer_gpu()
torch.cuda.empty_cache()

# Load Tokenizer

print('Loading Tokenizer')
tokenizer = T5Tokenizer.from_pretrained("/mntnfs/med_data5/zhangzhihan/t5-large-ssm")
config = T5Config.from_pretrained("/mntnfs/med_data5/zhangzhihan/t5-large-ssm")
nlp = spacy.load("en_core_web_trf")

# Read WMT Data

file_list = ['2016','2017','2018','2019','2020','2021'] 

for year in file_list:
    save_name = '/mntnfs/med_data5/zhangzhihan/Time-aware-LM/wmtnews-preprocessed/wmtnews-filtered-' + year + '-perp.csv'
    dataset = '/mntcephfs/data/med/wmtnews/news-docs.'+year+'.en.filtered.gz'

    print(f'Reading Data {dataset}')
    month_tag = []
    full_index = []
    local_index = []
    wmt_text = []

    month = 2
    flag = 0
    for docid, (date, sentence_split_text, unsplit_text) in wmt_preprocess(dataset):
        flag += 1
        if int(date[4:6]) == month:
            month_tag.append(flag)
            month += 1
    month_tag.append(flag)

    random.seed(10)
    for i in range(len(month_tag)):
        if i == 0:
            local_index = range(0,month_tag[i])
        else:
            local_index = range(month_tag[i-1],month_tag[i])
        local_index = random.sample(local_index, 50) #zzh change from 1000 to 20 23/03/13
        full_index.append(local_index)
    full_index = list(chain.from_iterable(full_index))

    flag =0
    for docid, (date, sentence_split_text, unsplit_text) in wmt_preprocess(dataset):
        flag += 1
        if (flag in full_index):
            text = str(sentence_split_text, encoding='utf-8')
            text = text.split('\n') #'\n|.|!|?|;|"'
            wmt_text.extend(text) #zzh clean_up(text)
        else:
            continue


    # Calculate PPL

    print('Calculating ppl...')
    with open(save_name, 'w', newline='') as writefile:
        writer = csv.writer(writefile)
        writer.writerow(['id1', 'id2','input', 'output'])
        id_1 = 0
        id_2 = 0
        wmt_text_loss = []
        wmt_text_len = []
        for text in wmt_text:
            input_ = ""
            target = ""
            loss_list = []
            len_list = []
            doc = nlp(text)
            if len(doc.ents)==0:
                continue
            for ent in doc.ents:
                start_index = ent.start_char
                end_index = ent.end_char
                word = ent.text
                input_ = text[:start_index] + '<extra_id_{0}>' + text[end_index:]
                target = '<extra_id_{0}>' +" " + word +" " + '<extra_id_{1}>'
                input_ids = tokenizer(input_, padding= 'do_not_pad', return_tensors="pt").input_ids.to(device) #zzh .cuda()
                labels = tokenizer(target, padding= 'do_not_pad', return_tensors="pt").input_ids.to(device) #zzh .cuda()
                writer.writerow([id_1, id_2, input_, target])
                id_2 += 1
            id_1 += 1