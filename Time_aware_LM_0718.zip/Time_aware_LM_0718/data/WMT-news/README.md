## Download WMT News Crawl Dataset

```
bash wmt-download.run
```

## Preprocess WMT news
```
python wmtnews-preprocess.py
```
