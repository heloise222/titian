import gzip
import hashlib
import base64
from re import T
import pandas as pd
from scipy import stats
import numpy as np
import time
import os
import torch
import json
import csv
import pprint
from transformers import T5Tokenizer
import spacy
import random

try:
    spacy.prefer_gpu()
except:
    print('Can not run spacy.prefer_gpu()')

try:
    nlp = spacy.load("en_core_web_trf")
except:
    print('Can not load en_core_web_trf using spacy')

try:
    tokenizer = T5Tokenizer.from_pretrained('/mntnfs/med_data5/zhangzhihan/t5-large-ssm') #google/t5-large-ssm
except:
    print('Can not obtain tokenizer from google/t5-large-ssm')

sentinels=[]
num_sentinels = 100
for i in range(num_sentinels): #zzh 原代码是200，t5-large-ssm的tokenizer_config.json是100，原因是什么？这个数字可以随意修改吗？
    sentinels.append(f'<extra_id_{i}>')

def ssm(index, text):
    if text=='':
        return None
    input_ = ""
    target = ""
    sentinel_cnt=0
    previous_end=0
    doc = nlp(text)
    for ent in doc.ents:
        start_index = ent.start_char
        end_index = ent.end_char
        word = ent.text
        input_ = input_ + text[previous_end:start_index] + sentinels[sentinel_cnt]
        target = target + sentinels[sentinel_cnt]+" " + word +" "
        previous_end = end_index
        sentinel_cnt+=1
        if sentinel_cnt == num_sentinels-1 : break
    input_ = input_ + text[previous_end:]
    target = target + sentinels[sentinel_cnt]
    if target.strip() == '<extra_id_0>': 
        return None
    return index, text, input_, target

def wmt_preprocess(file):
  with gzip.open(file) as gz_file:
    for line in gz_file:
      date, sentence_split_text, unsplit_text = line.decode('utf-8').strip().split('\t') #.encode('utf-8')
      docid = hashlib.sha256(unsplit_text.encode('utf-8')).hexdigest()
      sentence_split_text = base64.b64decode(sentence_split_text)
      unsplit_text = base64.b64decode(unsplit_text)
      yield docid, (date, sentence_split_text, unsplit_text)


length_limit = 350 #The limit of words per input # change from 250 to 350, since 350 is in training config
train_num = 20000 #20000 for year, 2000 for future
val_num = 2000
test_num = 2000
sample_num = train_num + val_num + test_num
file_list = ['2016','2017','2018','2019','2020','2021']
# full list: '2007','2008','2009', '2010', '2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021'
file_length = {'2007':183087,'2008':677238,'2009':862923,'2010':402493,'2011':909499,'2012':758958,'2013':1146387,'2014':1074842,\
    '2015':1089891,'2016':803316,'2017':5251273,'2018':2283184,'2019':1258408,'2020':1606654,'2021':1555033}

#每年，选20万train articles，选2K test articles，train articles中混入TempLAMA本年的train set，test articel中混入本年的valid set
#那test set呢？每年在train future后，做一次test，但是我们是predict，怎么设计？test set混入每年的perp测试集中，
# TempLAMA的输入，变成 In yearXX, ...


for year in file_list:

    ### WMT Data ###

    file_name = '/mntcephfs/data/med/wmtnews/news-docs.'+ year +'.en.filtered.gz'
    save_train_nolama = '/mntnfs/med_data5/zhangzhihan/Time-aware-LM/wmtnews-preprocessed/wmtnews-filtered-' + year + '-nolama-year.csv'
    save_val_nolama = '/mntnfs/med_data5/zhangzhihan/Time-aware-LM/wmtnews-preprocessed/wmtnews-filtered-' + year + '-nolama-future.csv'
    save_test_nolama = '/mntnfs/med_data5/zhangzhihan/Time-aware-LM/wmtnews-preprocessed/wmtnews-filtered-' + year + '-nolama-perp.csv'
    
    sample_index = random.sample(range(file_length[year]), sample_num)
    train_index = sample_index[: train_num]
    val_index = sample_index[train_num : train_num + val_num]
    test_index = sample_index[train_num + val_num : ]
    train_index.sort()
    val_index.sort()
    test_index.sort()

    if year != '2016':
        print('Start processing nolama-',year)

        with open(save_train_nolama, 'w', newline='') as writefile:
            writer = csv.writer(writefile)
            writer.writerow(['index','original', 'input', 'output'])
            article_index = 0
            for docid, (date, sentence_split_text, unsplit_text) in wmt_preprocess(file_name):
                article_index += 1
                if article_index not in train_index:
                    continue
                else:
                    text = str(unsplit_text, encoding='utf-8')
                    text = text.replace('\n', '')
                    if len(text.split()) > length_limit:
                        word_list = text.split()
                        seg1 = word_list[:length_limit]
                        try:
                            segment1, seg2_a = (' '.join(seg1)).rsplit('.',1)
                        except ValueError as e:
                            seg2_a = ''
                        segment2 = seg2_a + (' '.join(word_list[length_limit:]))
                        output = ssm(article_index, segment1)
                        if output: 
                            writer.writerow([output[0], output[1], output[2], output[3]])

                        while(len(segment2.split()) > length_limit):
                            word_list = segment2.split()
                            seg1_ = word_list[:length_limit]
                            if '.' in ' '.join(seg1_):
                                segment1_, seg2_a_ = (' '.join(seg1_)).rsplit('.',1)
                                segment2 = seg2_a_ + (' '.join(word_list[length_limit:]))
                            else:
                                segment1_ = ' '.join(seg1_)
                                segment2 = (' '.join(word_list[length_limit:]))
                            output = ssm(article_index, segment1_)
                            if output:  
                                writer.writerow([output[0], output[1], output[2], output[3]])
                    else:
                        output=ssm(article_index, text)
                        if output: 
                            writer.writerow([output[0], output[1], output[2], output[3]])

        with open(save_val_nolama, 'w', newline='') as writefile:
            writer = csv.writer(writefile)
            writer.writerow(['index','original', 'input', 'output'])
            article_index = 0
            for docid, (date, sentence_split_text, unsplit_text) in wmt_preprocess(file_name):
                article_index += 1
                if article_index not in val_index:
                    continue
                else:
                    text = str(unsplit_text, encoding='utf-8')
                    text = text.replace('\n', '')
                    if len(text.split()) > length_limit:
                        word_list = text.split()
                        seg1 = word_list[:length_limit]
                        try:
                            segment1, seg2_a = (' '.join(seg1)).rsplit('.',1)
                        except ValueError as e:
                            seg2_a = ''
                        segment2 = seg2_a + (' '.join(word_list[length_limit:]))
                        output = ssm(article_index, segment1)
                        if output: 
                            writer.writerow([output[0], output[1], output[2], output[3]])

                        while(len(segment2.split()) > length_limit):
                            word_list = segment2.split()
                            seg1_ = word_list[:length_limit]
                            if '.' in ' '.join(seg1_):
                                segment1_, seg2_a_ = (' '.join(seg1_)).rsplit('.',1)
                                segment2 = seg2_a_ + (' '.join(word_list[length_limit:]))
                            else:
                                segment1_ = ' '.join(seg1_)
                                segment2 = (' '.join(word_list[length_limit:]))
                            output = ssm(article_index, segment1_)
                            if output:  
                                writer.writerow([output[0], output[1], output[2], output[3]])
                    else:
                        output=ssm(article_index, text)
                        if output: 
                            writer.writerow([output[0], output[1], output[2], output[3]])
        
        with open(save_test_nolama, 'w', newline='') as writefile:
            writer = csv.writer(writefile)
            writer.writerow(['index','original', 'input', 'output'])
            article_index = 0
            for docid, (date, sentence_split_text, unsplit_text) in wmt_preprocess(file_name):
                article_index += 1
                if article_index not in test_index:
                    continue
                elif article_index in test_index:
                    text_all_sentences = str(sentence_split_text, encoding='utf-8') # unsplit_text
                    text_all_sentences = text_all_sentences.split('\n') # text = text.replace('\n', '')
                    for text_i in text_all_sentences:
                        if text_i=='':
                            continue
                        input_ = ""
                        target = ""
                        doc = nlp(text_i)
                        if len(doc.ents)==0:
                            continue
                        for ent in doc.ents:
                            start_index = ent.start_char
                            end_index = ent.end_char
                            word = ent.text
                            input_ = text_i[:start_index] + '<extra_id_{0}>' + text_i[end_index:]
                            target = '<extra_id_{0}>' +" " + word +" " + '<extra_id_{1}>'
                            #test_news.append([article_index, text_i, input_, target])
                            writer.writerow([article_index, text_i, input_, target])

    ### TempLAMA Data ###

    train_file = '/home/zhangzhihan/Time-aware-LM/data/TempLAMA/train.json'
    val_file = '/home/zhangzhihan/Time-aware-LM/data/TempLAMA/val.json'
    test_file = '/home/zhangzhihan/Time-aware-LM/data/TempLAMA/test.json'
    save_train_mix = '/mntnfs/med_data5/zhangzhihan/Time-aware-LM/wmtnews-preprocessed/wmtnews-filtered-' + year + '-mix-year.csv'
    save_val_mix = '/mntnfs/med_data5/zhangzhihan/Time-aware-LM/wmtnews-preprocessed/wmtnews-filtered-' + year + '-mix-future.csv'
    save_test_mix = '/mntnfs/med_data5/zhangzhihan/Time-aware-LM/wmtnews-preprocessed/wmtnews-filtered-' + year + '-mix-perp.csv'

    print('Start processing mix-',year)

    train_news = pd.read_csv(save_train_nolama)
    train_templama = []
    query_index = 0
    file_ = open(train_file, 'r', encoding='utf-8')
    for line in file_.readlines():
        dic = json.loads(line)
        train_templama.append(dic)
    for qa in train_templama:
        if qa['date'] == str(year):
            query_index += 1
            text = 'In '+ qa['date'] + ' ' + qa['query']
            text = text.replace('_X_',qa['most_frequent_answer']['name'])
            output = ssm(query_index, text)
            if output:
                #train_news.append([output[0], output[1], output[2], output[3]])
                train_news.loc[len(train_news.index)] = [output[0], output[1], output[2], output[3]]
    pd.DataFrame(train_news, columns=['index','original', 'input', 'output']).to_csv(save_train_mix)
    print('Saved ',save_train_mix)
    
    val_news = pd.read_csv(save_val_nolama)
    val_templama = []
    query_index = 0
    file_ = open(val_file, 'r', encoding='utf-8')
    for line in file_.readlines():
        dic = json.loads(line)
        val_templama.append(dic)
    for qa in val_templama:
        if qa['date'] == str(year):
            query_index += 1
            text = 'In '+ qa['date'] + ' ' + qa['query']
            text = text.replace('_X_',qa['most_frequent_answer']['name'])
            output = ssm(query_index, text)
            if output:
                #val_news.append([output[0], output[1], output[2], output[3]])
                val_news.loc[len(val_news.index)] = [output[0], output[1], output[2], output[3]]
    pd.DataFrame(val_news, columns=['index','original', 'input', 'output']).to_csv(save_val_mix)
    print('Saved ',save_val_mix)
    
    test_news = pd.read_csv(save_test_nolama)
    test_templama = []
    query_index = 0
    file_ = open(test_file, 'r', encoding='utf-8')
    for line in file_.readlines():
        dic = json.loads(line)
        test_templama.append(dic)
    for qa in test_templama:
        if qa['date'] == str(year):
            query_index += 1
            text = 'In '+ qa['date'] + ' ' + qa['query']
            input_ = text.replace('_X_', '<extra_id_0>')
            target = '<extra_id_0> ' + qa['most_frequent_answer']['name'] + ' <extra_id_1>'
            text = text.replace('_X_',qa['most_frequent_answer']['name'])
            #test_news.append([query_index, text, input_, target])
            test_news.loc[len(test_news.index)] = [output[0], output[1], output[2], output[3]]
    pd.DataFrame(test_news, columns=['index','original', 'input', 'output']).to_csv(save_test_mix)
    print('Saved ',save_test_mix)
    

