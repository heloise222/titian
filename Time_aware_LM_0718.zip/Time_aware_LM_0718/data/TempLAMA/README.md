## Download TempLAMA:
```
wget https://storage.googleapis.com/gresearch/templama/train.json
wget https://storage.googleapis.com/gresearch/templama/val.json
wget https://storage.googleapis.com/gresearch/templama/test.json
```
## Preprocess TempLAMA
```
python TempLAMA-preprocess.py
```
