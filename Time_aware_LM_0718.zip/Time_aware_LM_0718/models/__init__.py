from models.T5_Model import T5 as T5_Model

def load_model(type: str):
    return T5_Model
